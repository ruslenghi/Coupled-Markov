package coupledmcmc;

import beast.core.Distribution;
import beast.core.Input;
import beast.core.State;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SumOfDistributions extends Distribution {

    public Input<List<Distribution>> distributionsInput = new Input<>("distribution",
            "Distributions to average.",
            new ArrayList<>());

    @Override
    public double calculateLogP() {
        double P = 0.0;

        for (Distribution distrib: distributionsInput.get()) {
            P += Math.exp(distrib.calculateLogP());
        }

        logP = Math.log(P);
        return logP;
    }

    @Override
    public List<String> getArguments() {
        return null;
    }

    @Override
    public List<String> getConditions() {
        return null;
    }

    @Override
    public void sample(State state, Random random) {

    }
}

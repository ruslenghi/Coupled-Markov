package coupledmcmc;
import java.util.Formatter;
import java.util.*;
import java.util.Random;
import java.lang.Math;
import java.io.*;

public class CoupledMCMCBasic {

    // This method produces two values from the maximal coupling of two normal distributions.
    // It is possible to set the center and the standard deviations of the two distributions
    // through the parameters m_1/2 (center of the 1st/2nd distr) and sgm_1/2 (sd of the 1st/2nd distr)
    public static double[] Max_Coup(double m_1, double sgm_1, double m_2, double sgm_2) {
        Random randomno = new Random();
        double[] v;
        v = new double[2];
        double X = m_1 + sgm_1 * randomno.nextGaussian();
        double a = 1 / (sgm_1 * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * Math.pow((X - m_1) / sgm_1, 2));
        double U = randomno.nextDouble() * a;
        double b = 1 / (sgm_2 * Math.sqrt(2 * Math.PI)) * Math.exp((-0.5 * Math.pow((X - m_2) / sgm_2, 2)));
        if (U < b) {
            v[0] = X;
            v[1] = X;
        } else {
            boolean check = false;
            while (!check) {
                double Y = m_2 + sgm_2 * randomno.nextGaussian();
                double c = 1 / (sgm_2 * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * Math.pow((Y - m_2) / sgm_2, 2));
                double d = 1 / (sgm_1 * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * Math.pow((Y - m_1) / sgm_1, 2));
                double V = randomno.nextDouble() * c;
                if (V > d) {
                    check = true;
                    v[0] = X;
                    v[1] = Y;
                }
            }
        }
        return v;
    }

    // This method returns the result of a Markov step starting in X_t
    // With a normal distribution function (center = 0, sd=1) as proposal distribution
    // Be careful! This method has to be modified in case you want to use it for a different probability distribution
    // As it is, it only works for the linear combination of two normal distributions centered in +/-4 with sd=1
    public static double Markov_Step(double X_t, double sgm_q) {
        Random randomno = new Random();
        double prop = X_t + sgm_q * randomno.nextGaussian();
        double num = Math.exp(-0.5 * Math.pow((prop - 4), 2)) + Math.exp(-0.5 * Math.pow((prop + 4), 2));
        double den = Math.exp(-0.5 * Math.pow((X_t - 4), 2)) + Math.exp(-0.5 * Math.pow((X_t + 4), 2));
        double alpha = num / den;
        double U = randomno.nextDouble();
        if (alpha >= U) {
            return prop; }
        else { return X_t; }
    }

    // I need to use this method in the main. Again be careful! It needs to be changed
    // if you intend to sample probability distributions that are not
    // the linear combinations of normal distributions mentioned above
    public static double Probability(double z, double w) {
        double a = Math.exp(-0.5 * Math.pow((z - 4), 2)) + Math.exp(-0.5 * Math.pow((z + 4), 2));
        double b = Math.exp(-0.5 * Math.pow((w - 4), 2)) + Math.exp(-0.5 * Math.pow((w + 4), 2));
        if (b != 0) {
            double c = a / b;
            return c; }
        else { return -1; }
    }

    // This is method that is used to evaluate observables on the samples produced
    // by the Markov chains without wasting useful information.
    // The implementation of this method here only accounts observables that are indicator functions
    // the "start" and "finish" parameters set the boundaries of the indicator function
    // Be careful! If you want to consider different observables you have to modify
    // this method accordingly to your needs
    public static double H_mk(int m, int k, List<java.lang.Double> X, List<java.lang.Double> Y, double start, double finish) {
        double term_1 = 0;
        for (int i = 0; i < (m - k); i++) {
            if (X.get(k + i) <= finish & X.get(k + i) >= start) { term_1 += 1; }
        }
        term_1 = term_1 * 1 / (m - k - 1);
        int meet = 1;
        while (!X.get(meet).equals(Y.get(meet - 1))) { meet += 1; }
        double term_2 = 0;
        for (int l = 0; l < (meet - k - 1); l++) {
            int a = 0;
            int b = 0;
            if (X.get(l + 1 + k) <= finish & X.get(l + 1 + k) >= start) { a += 1; }
            if (Y.get(l + k) <= finish & Y.get(l + k) >= start) { b += 1; }
            term_2 += Math.min(1, (l + 1) / (m - k + 1)) * (a - b);
        }
        return term_1 + term_2;
    }

    // Here I actually use the methods implemented above to get unbiased samples for the distribution
    // given by the linear combination of the two normal distributions centered in +/-4
    public static void main(String[] args) throws Exception{

        Random randomno = new Random();
        double sgm_q = 1; // sd for the normal proposal distribution in the Markov_Step method
        int k = 50; // k parameter in the H_mk method
        int m = 500; // m parameter in the H_mk method
        int n_iter = 1000; // number of couples of chains that you want to draw

        // In case of bad initialization this "n_iter" parameter should be increased
        // to compensate for the poor choice of the initialization distribution
        // Here the initialization is deliberately bad, and as a consequence "n_iter" has to be large


        // I prepare a matrix "M" to store the values of the 64 indicator function observables that i am interested in
        // I am interested in these 64 indicator functions because I want to use them to make a histogram of the
        // distribution obtained by using the Markov Chains
        double[][] M = new double[n_iter][64];
        double avg = 0; // I use this variable to count the average number of steps taken for two chains to meet

        for (int i = 0; i < n_iter; i++) {
            boolean control = false;
            // I perform the first steps of the two chains. Two for X and one for Y.
            List<Double> X = new ArrayList<>();
            List<Double> Y = new ArrayList<>();
            double X_0 = 10 + randomno.nextGaussian(); // Poor proposal distribution
            X.add(X_0);
            double X_1 = Markov_Step(X_0, sgm_q);
            X.add(X_1);
            double Y_0 = 10 + randomno.nextGaussian(); // Poor proposal distribution
            Y.add(Y_0);
            double X_t = X_1;
            double Y_t_prev = Y_0;
            int count = 0;

            int steps_b4_meet = 1;
            while (count < m - 1) {
                double[] v;
                v = Max_Coup(X_t, sgm_q, Y_t_prev, sgm_q);
                double X_star = v[0];
                double Y_star = v[1];
                double U = randomno.nextDouble();
                if (Probability(X_star, X_t) == -1) {
                    i -= 1;
                    control = true;
                    break;
                }
                if (U <= Math.min(1, Probability(X_star, X_t))) { X_t = X_star; }
                if (Probability(Y_star, Y_t_prev) == -1) {
                    i -= 1;
                    control = true;
                    break;
                }
                if (U <= Math.min(1, Probability(Y_star, Y_t_prev))) { Y_t_prev = Y_star; }
                X.add(X_t);
                Y.add(Y_t_prev);
                if (Y_t_prev != X_t) { steps_b4_meet += 1; }
                count += 1; }

            while (Y_t_prev != X_t & !control) {
                steps_b4_meet += 1;
                double[] v;
                v = Max_Coup(X_t, sgm_q, Y_t_prev, sgm_q);
                double X_star = v[0];
                double Y_star = v[1];
                double U = randomno.nextDouble();
                if (Probability(X_star, X_t) == -1) {
                    i -= 1;
                    control = true;
                    break;
                }
                if (U <= Math.min(1, Probability(X_star, X_t))) { X_t = X_star; }
                if (Probability(Y_star, Y_t_prev) == -1) {
                    i -= 1;
                    control = true;
                    break;
                }
                if (U <= Math.min(1, Probability(Y_star, Y_t_prev))) { Y_t_prev = Y_star; }
                X.add(X_t);
                Y.add(Y_t_prev);
            }

            if (!control) {
                for (int j = 0; j < 64; j++) {
                    M[i][j] = H_mk(m, k, X, Y, -8 + j * 0.25, -8 + (j + 1) * 0.25);
                }
            }

            avg += steps_b4_meet / (double) n_iter;
            if (X.size() > 501 & !control) {
                System.out.println("Outlier! " + steps_b4_meet + " steps before meeting" );
                System.out.println("Outlier contribution " + H_mk(m, k, X, Y, 2.25, 2.5));
            }
        }

        System.out.println("Average Meeting: " + avg);

        // I print the results for the observables values to a text file
        double[] values;
        values = new double[64];

        FileOutputStream fout=new FileOutputStream("Outlier.txt");
        PrintStream pout=new PrintStream(fout);

        for (int j = 0; j < 64; j++) {
            double temp = 0;
            for (int i = 0; i < n_iter; i++) {
                temp += M[i][j];
            }
            temp = temp/(double) n_iter;
            values[j] = temp;
            pout.println(temp);
        }

        pout.close();
        fout.close();

    }
}
package coupledmcmc;

import beast.core.*;
import beast.core.Runnable;
import beast.core.parameter.RealParameter;
import beast.util.Randomizer;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static coupledmcmc.CoupledMCMCBasic.Markov_Step;

public class CoupledMCMC2D extends Runnable {

    public Input<Integer> numberOfChainsInput = new Input<>("numberOfChains",
            "Number of of coupled mcmc chains.", Input.Validate.REQUIRED);

    public Input<RealParameter> xInput = new Input<>("x",
            "Parameter to sample using coupled MCMC.",
            Input.Validate.REQUIRED);

    public Input<Distribution> distributionInput = new Input<>("distribution",
            "Distribution to sample from",
            Input.Validate.REQUIRED);

    public Input<String> outputFileInput = new Input<>("outputFile",
            "Name of output file.",
            Input.Validate.REQUIRED);

    int numberOfChains;
    RealParameter x;
    Distribution distribution;

    @Override
    public void initAndValidate() {
        numberOfChains = numberOfChainsInput.get();
        x = xInput.get();
        distribution = distributionInput.get();

        // Example usages follow:

        // x.getValue(); // Get _current_ value of parameter.
        // x.setValue(3.0);  // Set _new_ value of parameter.
        // double logP = distribution.calculateLogP(); // Compute distribution given _current_ value of parameter.

    }

    @Override
    public void run() throws Exception {

        double sgm_0 = 500;
        double sgm_1 = 25;
        int k = 50;
        int m = 500;
        int points = 50;
        double length_x = 40000;
        double length_y = 600;
        int incr_1 = (int) length_x/points;
        int incr_2 = (int) length_y/points;
        double[][][] M = new double[numberOfChains][points][points];

        double avg = 0;

        shape(500,10000);
        shape(10000,500);

        for (int i = 0; i < numberOfChains; i++) {
            System.out.println(i);
            List<double[]> X = new ArrayList<>();
            List<double[]> Y = new ArrayList<>();
            double[] X_0 = {500 * Randomizer.nextGaussian() + 10000, 50 * Randomizer.nextGaussian() + 500};
            X.add(X_0);
            double[] X_1 = Markov_Step(X_0, sgm_0, sgm_1);
            X.add(X_1);
            double[] Y_0 = {500 * Randomizer.nextGaussian() + 10000, 50 * Randomizer.nextGaussian() + 500};
            Y.add(Y_0);
            double[] X_t = X_1;
            double[] Y_t_prev = Y_0;
            int count = 0;

            int steps_b4_meet = 1;
            while (count < m - 1) {
                double[][] v;
                v = Max_Coup(X_t, Y_t_prev, sgm_0, sgm_1);
                double[] X_star = v[0];
                double[] Y_star = v[1];
                double U = Randomizer.nextDouble();
                if (U <= Math.min(1, Probability(X_star, X_t))) {
                    X_t = X_star;
                }
                if (U <= Math.min(1, Probability(Y_star, Y_t_prev))) {
                    Y_t_prev = Y_star;
                }
                X.add(X_t);
                Y.add(Y_t_prev);
                if ((Y_t_prev[0] != X_t[0]) && (Y_t_prev[1] != X_t[1])) {
                    steps_b4_meet += 1;
                }
                count += 1;
            }

            if ((Y_t_prev[0] != X_t[0]) && (Y_t_prev[1] != X_t[1])) {
                System.out.println("Outlier!");
            }

            while ((Y_t_prev[0] != X_t[0]) && (Y_t_prev[1] != X_t[1])) {
                steps_b4_meet += 1;
                double[][] v;
                v = Max_Coup(X_t, Y_t_prev, sgm_0, sgm_1);
                double[] X_star = v[0];
                double[] Y_star = v[1];
                double U = Randomizer.nextDouble();
                if (U <= Math.min(1, Probability(X_star, X_t))) {
                    X_t = X_star;
                }
                if (U <= Math.min(1, Probability(Y_star, Y_t_prev))) {
                    Y_t_prev = Y_star;
                }
                X.add(X_t);
                Y.add(Y_t_prev);
            }

            avg += steps_b4_meet / (double) numberOfChains;

            // Here we compute the shape of the distribution, so that we can visualize it on python later
            for (int j = 0; j < points; j++) {
                for (int l = 0; l < points; l++) {
                    double[] start = {j * incr_1,  400 + l * incr_2};
                    double[] finish = {(j + 1) * incr_1, 400 + (l + 1) * incr_2};
                    M[i][j][l] = H_mk(m, k, X, Y, start, finish);
                }
            }
        }

        FileOutputStream fout = new FileOutputStream("mfile.txt");
        PrintStream pout = new PrintStream(fout);

        double[][] result = new double[points][points];
        for (int j = 0; j < points; j++) {
            for (int l = 0; l < points; l++) {
                double a = 0;
                for (int i = 0; i < numberOfChains; i++) {
                    a += M[i][j][l];
                }
                a = a / (double) numberOfChains;
                result[j][l] = a;
                pout.println((float) result[j][l]);
            }
            pout.println(" ");
        }
        pout.close();
        fout.close();

        System.out.println("The average length of the chain is ---> " + avg);
    }

    public double[][] Max_Coup(double[] m_1, double[] m_2, double sgm_0, double sgm_1) {
        double[][] v = new double[2][2];
        double[] X;
        double[] Y;
        X = new double[2];
        Y = new double[2];
        X[0] = m_1[0] + sgm_0 * Randomizer.nextGaussian();
        X[1] = m_1[1] + sgm_1 * Randomizer.nextGaussian();
        double a = 1 / (Math.sqrt(sgm_0*sgm_1) * (2 * Math.PI)) * Math.exp(-0.5 * (Math.pow((X[0] - m_1[0]) / sgm_0, 2) + Math.pow((X[1] - m_1[1]) / sgm_1, 2)));
        double U = Randomizer.nextDouble() * a;
        double b = 1 / (Math.sqrt(sgm_0*sgm_1)* (2 * Math.PI)) * Math.exp(-0.5 * (Math.pow((X[0] - m_2[0]) / sgm_0, 2) + Math.pow((X[1] - m_2[1]) / sgm_1, 2)));
        if (U < b) {
            v[0] = X;
            v[1] = X;
        } else {
            boolean check = false;
            while (!check) {
                Y[0] = m_2[0] + sgm_0 * Randomizer.nextGaussian();
                Y[1] = m_2[1] + sgm_1 * Randomizer.nextGaussian();
                double c = 1 / (Math.sqrt(sgm_0*sgm_1) * (2 * Math.PI)) * Math.exp(-0.5 * (Math.pow((Y[0] - m_2[0]) / sgm_0, 2) + Math.pow((Y[1] - m_2[1]) / sgm_1, 2)));
                double d = 1 / (Math.sqrt(sgm_0*sgm_1) * (2 * Math.PI)) * Math.exp(-0.5 * (Math.pow((Y[0] - m_1[0]) / sgm_0, 2) + Math.pow((Y[1] - m_1[1]) / sgm_1, 2)));
                double V = Randomizer.nextDouble() * c;
                if (V > d) {
                    check = true;
                    v[0] = X;
                    v[1] = Y;
                }
            }
        }
        return v;
    }


    public void shape(double a, double b) {
        x.setValue(0, (double) a);
        x.setValue(1, (double) b);
        System.out.println(getLogP());
        //value = Math.exp(value);
    }

    public double getLogP() {
        CoupledMCMCUtils.makeEverythingDirty(distribution);
        return distribution.calculateLogP();
    }

    public double[] Markov_Step(double[] X_t, double sgm_0, double sgm_1) {
        double[] prop = new double[2];
        prop[0] = X_t[0] + sgm_0 * Randomizer.nextGaussian();
        prop[1] = X_t[1] + sgm_1 * Randomizer.nextGaussian();
        x.setValue( 0, prop[0] );
        x.setValue( 1, prop[1] );
        // You might want to use the logarithm here
        //double num = distribution.calculateLogP();
        double num = getLogP();
        x.setValue( 0, X_t[0] );
        x.setValue( 1, X_t[1] );
        //double den = distribution.calculateLogP();
        double den = getLogP();
        double log_alpha = num - den;
        double U = Randomizer.nextDouble();
        if (Math.exp(log_alpha) >= U) {
            return prop; }
        else { return X_t; }
    }

    public double Probability(double[] z, double[] w) {
        x.setValue(0,z[0]);
        x.setValue(1,z[1]);
        //double a = distribution.calculateLogP();
        double a = getLogP();
        x.setValue(0,w[0]);
        x.setValue(1,w[1]);
        //double b = distribution.calculateLogP();
        double b = getLogP();
        double c = a - b;
        c = Math.exp(c);
        return c;
    }

    // This is method that is used to evaluate observables on the samples produced
    // by the Markov chains without wasting useful information.
    // The implementation of this method here only accounts observables that are indicator functions
    // the "start" and "finish" parameters set the boundaries of the indicator function
    // Be careful! If you want to consider different observables you have to modify
    // this method accordingly to your needs
    public double H_mk(int m, int k, List<double[]> X, List<double[]> Y, double[] start, double[] finish) {
        double term_1 = 0;
        for (int i = 0; i < (m - k); i++) {
            if (X.get(k + i)[0] <= finish[0] & X.get(k + i)[0] >= start[0]) {
                if (X.get(k + i)[1] <= finish[1] & X.get(k + i)[1] >= start[1]) {
                    term_1 += 1;
                }
            }
        }
        term_1 = term_1 * 1 / (m - k - 1);
        int meet = 1;
        while (!X.get(meet).equals(Y.get(meet - 1))) {
            meet += 1;
        }
        double term_2 = 0;
        for (int l = 0; l < (meet - k - 1); l++) {
            int a = 0;
            int b = 0;
            if (X.get(l + 1 + k)[0] <= finish[0] & X.get(l + 1 + k)[0] >= start[0]) {
                if (X.get(l + 1 + k)[1] <= finish[1] & X.get(l + 1 + k)[1] >= start[1]) {
                    a += 1;
                }
                if (Y.get(l + k)[0] <= finish[0] & Y.get(l + k)[0] >= start[0]) {
                    if (Y.get(l + k)[1] <= finish[1] & Y.get(l + k)[1] >= start[1]) {
                        b += 1;
                    }
                }
            }
            term_2 += Math.min(1, (l + 1) / (m - k + 1)) * (a - b);
        }
        return term_1 + term_2;
    }

    // Question about this part?
    public static void main(String[] args) throws Exception {

        CoupledMCMC2D coupledMCMC = new CoupledMCMC2D();
        coupledMCMC.initByName("maxChainLength", "1000");
        coupledMCMC.run();

        System.out.println("Hi!");
    }

}


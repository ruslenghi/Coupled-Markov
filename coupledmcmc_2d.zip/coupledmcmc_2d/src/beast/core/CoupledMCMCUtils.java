package beast.core;

import java.util.List;

public class CoupledMCMCUtils {

    public static void makeEverythingDirty(CalculationNode node) {
        node.checkDirtiness();

        for (Input<?> input : node.getInputs().values()) {
            Object value = input.get();

            if (value instanceof CalculationNode) {
                makeEverythingDirty((CalculationNode) value);
            } else if (value instanceof List) {
                for (Object element : (List<?>)value) {
                    if (element instanceof CalculationNode) {
                        makeEverythingDirty((CalculationNode) element);
                    }
                }
            }
        }
    }
}
